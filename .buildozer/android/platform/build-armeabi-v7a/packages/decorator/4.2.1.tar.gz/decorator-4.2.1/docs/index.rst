Welcome to decorator's documentation!
=====================================

Contents:

.. toctree::
   :maxdepth: 2

   README
   tests.documentation
